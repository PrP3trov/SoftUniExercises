﻿namespace BorderControl.Models
{
    public abstract class BaseEntity
    {
        public string Id { get; set; }
    }
}
