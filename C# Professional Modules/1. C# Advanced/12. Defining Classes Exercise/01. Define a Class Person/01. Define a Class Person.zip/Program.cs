﻿namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person first = new Person("Peter",20);
            Person second = new Person("George",18);
            Person third = new Person("Jose",43);
        }
    }
    
}